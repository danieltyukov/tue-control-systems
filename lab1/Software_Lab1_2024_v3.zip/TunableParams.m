clear
Ts=1/2000;

reset=0;
resetEnc=0;

SigGen_Amplitude=0;
SigGen_Frequency=1;

Dist_Amplitude=0;


save RL_FA_controller_5ESD0.mat